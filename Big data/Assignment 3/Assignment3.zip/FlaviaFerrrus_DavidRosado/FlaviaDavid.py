from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import requests
import pandas as pd
import pickle
from sklearn.linear_model import LogisticRegression
from sklearn.utils import shuffle
# Default arguments for the DAG
default_args = {
    'owner': 'Flavia David', # Owner of the DAG
    'start_date': datetime.now() - timedelta(days=1), # Start date of the DAG
    'depends_on_past': False, # DAG does not depend on past runs
    'email': ['rosadodav@ipm.cat'], # Email address to receive DAG logs
    'email_on_failure': False, # Do not send email on failure
    'email_on_retry': False, # Do not send email on retry
    'retries': 1, # Number of retries
    'retry_delay': timedelta(minutes=1) # Time between retries
}
var = Variable.get("settings", deserialize_json=True)
data_url = var["data_url"]
local_path = var["local_path"]
n_samples = var["n_samples"]
predict_url = var["predict_url"]
# Task 1. Download all csv from s3 bucket and store locally.
def download_store():

    # Initialize empty dataframe
    final_df = pd.DataFrame()

    # Loop through all files in the bucket
    for file in requests.get(data_url).text.split("\n"):
        # Read csv file and concatenate to final_df
        final_df = pd.concat([final_df, pd.read_csv(file)])

    # Store final_df as csv
    final_df.to_csv(local_path + "train.csv", index = False)

# Task 2. Read all the downloaded csv and train the model and finally save the model locally.
def train_model():
    # Read csv file
    data = pd.read_csv(local_path + "train.csv")

    # Separate features and target
    X = data.drop(["Species"], axis=1).values
    y = data[["Species"]]

    # Shuffle arrays since y values are in order
    X_new, y_new = shuffle(X, y, random_state=0)
    n_samples_train = int(var["n_samples"])

    # Train test split
    X_train = X_new[:n_samples_train, :]
    y_train = y_new[:n_samples_train]

    X_test = X_new[n_samples_train:, :]
    y_test = y_new[n_samples_train:]

    # Fit logistic regression model
    clf = LogisticRegression().fit(X_train, y_train)

    # Save model
    with open('iris_trained_model.pkl', 'wb') as f:
        pickle.dump(clf, f)

# Task 3. Download prediction.csv from S3 save it locally.
def download_prediction():
    # Download prediction.csv from S3
    pd.read_csv(predict_url).to_csv(local_path + "predict.csv", index = False)

# Task 4. Load the local model and read the downloaded prediction
# CSV and save a csv with prediction for each input.
def predict():
    # Load model
    with open('iris_trained_model.pkl', 'rb') as f:
        clf = pickle.load(f)

    # Read prediction.csv
    data = pd.read_csv(local_path + "predict.csv")

    # Predict
    pred = clf.predict(data)

    # Save predictions
    pd.DataFrame(pred).to_csv(local_path + "predict_result.csv", index = False)

    # Success message
    print("Prediction done! The prediction is")
    print(pd.read_csv(local_path + "predict_result.csv"))

# Define the DAG
dag = DAG("FlaviaDavid_dag",description='A DAG scheduled for 8 PM every Monday',
          default_args=default_args, catchup=False, schedule_interval='0 20 * * 1')
with dag:
    # Task 1
    t1 = PythonOperator(task_id="Task1",python_callable=download_store)

    # Task 2
    t2 = PythonOperator(task_id="Task2",python_callable=train_model)

    # Task 3
    t3 = PythonOperator(task_id="Task3",python_callable=download_prediction)

    # Task 4
    t4 = PythonOperator(task_id="Task4",python_callable=predict)

# Define dependencies
t1 >> t2 >> t4
t3 >> t4


