Team names:
	Flàvia Ferrús.
	David Rosado.

Contents:
	Dag.png --> Screenshot of the Dag in Airflow.
	Execution.png --> Screenshot of one execution in airflow.
	FlaviaDavid.py --> Python Code for the airflow dag.
	logs --> Log folder of the manual execution.